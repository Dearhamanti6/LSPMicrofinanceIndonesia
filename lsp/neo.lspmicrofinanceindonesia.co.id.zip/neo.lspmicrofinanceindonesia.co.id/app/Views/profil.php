<section class="" style="background: url('https://bri-institute.ac.id/wp-content/uploads/2020/04/Focus-group-Discussion-BRI-Institute-dan-Anggota-Aftech-2.jpeg')no-repeat center center / cover">
            <div class="section-lg bg-gradient-primary text-white section-header">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-7">
                            <div class="page-header-content text-center">
                                <h1>About Us</h1>
                                <nav aria-label="breadcrumb" class="d-flex justify-content-center">
                                    <ol class="breadcrumb breadcrumb-transparent breadcrumb-text-light">
                                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">About Us</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</section>
<section class="section section-lg bg-soft">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-9 col-lg-8">
                        <div class="section-heading text-center">
                            <h2>LSP Microfinance</h2>
                            <p class="lead">Latar Belakang Lembaga Sertifikasi Profesi Microfinance.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                <?php if(!empty($content)){
                        echo $content['contentText'];    
                    }else{
                    }?>
                            <!-- <div class="col-md-12">
                                <p class="lead" style="text-align: justify;">
                                    <b>Tiga Macam Bentuk LSP</b> 
                                </p>
                                        <div class="col-md-12">
                                            <table class="table table-striped" border="2px">
                                                <thead style="background-color: orange;">
                                                    <tr align="center">
                                                    <th style="width: 200px;"><b>Bentuk LSP</b></th> 
                                                    <th><b>Pendiri</b></th>
                                                    <th><b>Market</b></th>  
                                                    </tr> 
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <th><center><b>LSP 1</b></center></th>
                                                        <th>Lembaga pendidikan dan/atau  pelatihan</th>
                                                        <th>Jejaring kerja lembaga induk, sesuai  dengan ruang lembaga yaitu peserta  didiknya (mahasiswa/i).
                                                        </th>
                                                    </tr>
                                                    <tr>
                                                        <th><center><b>LSP 2</b></center></th>
                                                        <th>Industri atau instansi</th>
                                                        <th>SDM dari jejaring kerjanya, sesuai  dengan ruang lingkup instansi atau  industri yaitu para pekerjanya.
                                                        </th>
                                                    </tr>
                                                    <tr>
                                                        <th><center><b>LSP 3</b></center></th>
                                                        <th> Industri dan/atau asosiasi profesi
                                                        </th>
                                                        <th>Sektor dan atau profesi tertentu sesuai  ruang lingkup.
                                                        </th>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                            </div> -->
            <!-- <div class="col-md-12">
                <p class="lead" style="text-align: justify;">
                       <b>Dukungan Lembaga</b> 
                </p>
                

Dewan Nasional Keuangan Inklusi
Nomor:
OJK
Nomor:
BAPPENAS
Nomor:
Indonesia Microfinance Expert Association (IMFEA)
Nomor:

                <div class="project-details-feature">
                    <ul class="list-unstyled tech-feature-list">
                        <li class="py-1"><span class="ti-control-forward mr-2 text-secondary"></span><strong>Kementerian Koperasi dan UKM
                        Nomor: 194/Dep.2.5/IX/2020</strong>
                        </li>
                        <li class="py-1"><span class="ti-control-forward mr-2 text-secondary"></span><strong>Induk Koperasi Simpan Pinjam (IKSP)
                        Nomor: 001/Pengurus-IKSP/IX/2020
                        </strong>
                        </li>
                        <li class="py-1"><span class="ti-control-forward mr-2 text-secondary"></span><strong> Perlu adanya standar kompetensi dalam pengelolaan microfinance yang sehat dengan
                        kaidah-kaidah yang benar.</strong>
                        </li>
                        <li class="py-1"><span class="ti-control-forward mr-2 text-secondary"></span><strong>Bentuk komitmen BRI untuk mengembangkan bisnis mikro yang merupakan core  bisnis BRI.</strong></li>
                        <li class="py-1"><span class="ti-control-forward mr-2 text-secondary"></span><strong> Mengacu kepada Peraturan Otoritas Jasa Keuangan Nomor 1/POJK.07/2013 tentang  Perlindungan Konsumen Sektor Jasa Keuangan dan UU OJK tentang Edukasi dan  Perlindungan Konsumen dan POJK Nomor 76/POJK.07/2016 tentang  Peningkatan  Literasi dan Inklusi Keuangan di Sektor Jasa Keuangan Bagi Konsumen dan/atau  masyarakat.
                        </strong></li>
                        <li class="py-1"><span class="ti-control-forward mr-2 text-secondary"></span><strong>OJK sedang menyusun infrastruktur dan arsitektur LKM, salah satu infrastruktur
                        adalah adanya LSP untuk meningkatkan kompetensi pengurus LKM.</strong></li>
                    </ul>
                </div> -->
            </div>
        </div>
    </section>
