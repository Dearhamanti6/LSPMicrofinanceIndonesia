<!-- start blog-with-sidebar-section -->
<!-- start blog-with-sidebar-section -->
<section class="" style="background: url('https://bri-institute.ac.id/wp-content/uploads/2020/04/Focus-group-Discussion-BRI-Institute-dan-Anggota-Aftech-2.jpeg')no-repeat center center / cover">
            <div class="section-lg bg-gradient-primary text-white section-header">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-7">
                            <div class="page-header-content text-center">
                                <h1>Video</h1>
                                <nav aria-label="breadcrumb" class="d-flex justify-content-center">
                                    <ol class="breadcrumb breadcrumb-transparent breadcrumb-text-light">
                                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Video</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<section class="our-blog-section ptb-100 gray-light-bg">
    <div class="container">
        <div class="row">
                <?php
                if(!empty($all)) {
                    foreach($all as $v_all) {
                        ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="single-blog-card card border-0 shadow-sm">
                                <div class="blog-img">
                                    <a href="#"><span class="category position-absolute">Video</span></a>
                                    <a href="#"><img src="<?php echo $v_all['images'][0]['path'] ?>" class="card-img-top position-relative img-fluid" alt="blog"></a>
                                </div>
                                <div class="card-body">
                                    <h3 class="h5 mb-2 card-title"><a href="#"><?php echo $v_all['lvstTitle'] ?></a></h3>
                                    <!-- <p class="card-text">Some quick example text to build on the card title and make up the bulk.</p> -->
                                </div>
                                <div class="card-footer border-0 d-flex">
                                <a href="<?=base_url()?>/events/video/detail/<?php echo $v_all['lvstId'] ?>/<?php echo strtolower(url_title($v_all['lvstTitle']))?>" class="">Read more <span class="ti-arrow-right"></span></a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
                ?>
        </div>
    </div> <!-- end container -->
</section>
<!-- end blog-with-sidebar-section -->   