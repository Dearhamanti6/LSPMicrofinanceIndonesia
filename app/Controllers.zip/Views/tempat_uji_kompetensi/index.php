<section class="" style="background: url('https://bri-institute.ac.id/wp-content/uploads/2020/04/Focus-group-Discussion-BRI-Institute-dan-Anggota-Aftech-2.jpeg')no-repeat center center / cover">
    <div class="section-lg bg-gradient-primary text-white section-header">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-7">
                    <div class="page-header-content text-center">
                        <h1>Sertifikasi</h1>
                        <nav aria-label="breadcrumb" class="d-flex justify-content-center">
                            <ol class="breadcrumb breadcrumb-transparent breadcrumb-text-light">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Tempat Uji Kompetensi</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<br>
<section class="services-section ptb-100 gray-light-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="p-5 my-md-3 my-lg-3 my-sm-0 shadow-sm white-bg rounded">
                    <div class="row">
                        <div class="col-9">
                            <div class="services-content-wrap">
                                <h5>Tempat Uji Kompetensi</h5>
                            </div>
                        </div>
                    </div>
                    <table id="tuk-table" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th class="bg-primary text-white"><strong>No</strong></th>
                                <th class="bg-primary text-white"><strong>Kode</strong></th>
                                <th class="bg-primary text-white"><strong>Nama Tempat Uji Kompetensi</strong></th>
                                <th class="bg-primary text-white"><strong>Alamat</strong></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $this->section('javascript') ?>
    <script type="text/javascript">
        $(document).ready(function() {
            var table = $('#tuk-table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [],
                "ajax": {
                    "url": "<?php echo site_url('TempatUjiController/ajaxList') ?>",
                    "type": "POST"
                },
                "columnDefs": [{
                    "targets": [],
                    "orderable": false,
                }, ],
            });
        });
    </script>
<?= $this->endSection() ?>